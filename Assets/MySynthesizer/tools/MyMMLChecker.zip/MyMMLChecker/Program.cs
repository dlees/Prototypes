﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Linq;

using MySpace;
using MySpace.Synthesizer;
using MySpace.Synthesizer.PM8;
using MySpace.Synthesizer.SS8;
using MySpace.Synthesizer.CT8;
using MySpace.Synthesizer.MMLSequencer;

namespace MyMMLChecker
{
    class Program
    {
        static void WriteLine(string str)
        {
            Console.WriteLine(str);
        }
        static void Write(string str)
        {
            Console.Write(str);
        }
        static private bool Verbose = false;
        static private bool HitAnyKey = false;
        enum ExitCode
        {
            Ok = 0,
            Usage = -1,
            ReadFailed = -2,
            PaserError = -3,
            WriteFailed = -4,
        }
        static int Exit(ExitCode ec, string message)
        {
            WriteLine(message);
            if (HitAnyKey)
            {
                WriteLine("HIT ANY KEY!");
                Console.ReadKey();
            }
            return (int)ec;
        }
        private class MyTraceListener : TraceListener
        {
            public override void Write(string message)
            {
                Console.Write(message);
            }
            public override void WriteLine(string message)
            {
                Console.WriteLine(message);
            }
        }
        static int Main(string[] args)
        {
            Debug.Listeners.Add(new MyTraceListener());
            bool error = false;
            bool play = false;
            bool loop = false;
            float volume = -0.5f;
            bool output = false;
            string outputfile = null;
            string inputfile = null;
            string resourcePath = null;
            uint freq = 0;
            uint bps = 0;
            uint numVoices = 0;
            uint baseFreq = 0;
            var ct = StringComparison.CurrentCultureIgnoreCase;
            for (int i = 0; i < args.Length; i++)
            {
                var s = args[i];
                if (s[0] != '-')
                {
                    if (inputfile != null)
                    {
                        error = true;
                    }
                    inputfile = s;
                }
                else if (s.Equals("-v", ct) || s.Equals("-verbose", ct))
                {
                    Verbose = true;
                }
                else if (s.Equals("-p", ct) || s.Equals("-play", ct))
                {
                    play = true;
                }
                else if (s.Equals("-l", ct) || s.Equals("-loop", ct))
                {
                    loop = true;
                }
                else if (s.Equals("-h", ct) || s.Equals("-hit", ct))
                {
                    HitAnyKey = true;
                }
                else if (s.Equals("-o", ct) || s.Equals("-output", ct))
                {
                    if (outputfile != null)
                    {
                        error = true;
                    }
                    output = true;
                    if ((i + 1) < args.Length)
                    {
                        outputfile = args[++i];
                    }
                }
                else if (s.Equals("-f", ct) || s.Equals("-frequency", ct))
                {
                    int result;
                    if ((freq == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if ((result < 8000) || (result > 192000))
                        {
                            error = true;
                        }
                        freq = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-b", ct) || s.Equals("-bps", ct))
                {
                    int result;
                    if ((bps == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        switch (result)
                        {
                            case 8:
                            case 16:
                            case 24:
                            case 32:
                                bps = (uint)(result / 8);
                                break;
                            default:
                                error = true;
                                break;
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-nv", ct) || s.Equals("-maxnumvoices", ct))
                {
                    int result;
                    if ((numVoices == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if((result < 1) || (result > 32))
                        {
                            error = true;
                        }
                        numVoices = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-bf", ct) || s.Equals("-basefrequency", ct))
                {
                    int result;
                    if ((baseFreq == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if ((result < 8000) || (result > 192000))
                        {
                            error = true;
                        }
                        baseFreq = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-m", ct) || s.Equals("-mastervolume", ct))
                {
                    float result;
                    if ((volume < 0.0f) && ((i + 1) < args.Length) && float.TryParse(args[++i], out result))
                    {
                        if ((result < 0.0f) || (result > 1.0f))
                        {
                            error = true;
                        }
                        volume = result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-r", ct) || s.Equals("-resourcepath", ct))
                {
                    if (resourcePath != null)
                    {
                        error = true;
                    }
                    if ((i + 1) < args.Length)
                    {
                        resourcePath = args[++i];
                    }
                    else
                    {
                        error = true;
                    }
                }
                else
                {
                    error = true;
                }
            }
            if (play && output){
                error = true;
            }
            if(output && loop)
            {
                error = true;
            }
            if(inputfile == null)
            {
                error = true;
            }
            if (play && ((freq != 0) || (bps != 0)))
            {
                WriteLine("warning; freq & bps is ignored.");
            }
            if (error)
            {
                return Exit(ExitCode.Usage, "usage:\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] [-r path]\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] [-r path] -o [input.wav] [-f 44100] [-b 16] [-m 0.5]\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] [-r path] -p [-l] [-m 0.5]\n" +
                    "-v: Verbose\n" +
                    "-h: Hit Any Key!\n" +
                    "-p: Play direct\n" +
                    "-l: Loop\n" +
                    "-m: Master volume (0.0~1.0)\n" +
                    "-o: Output to file\n" +
                    "-f: Frequency(8000~..)\n" +
                    "-b: Bps(8,16,..)\n" +
                    "-nv: Numver of voices (1~32)\n" +
                    "-bf: Base frequency (8000~..)\n" +
                    "-r: Resource data path\n"
                    );
            }
            volume *= volume;
            if (numVoices == 0)
            {
                numVoices = 8;
            }
            if (baseFreq == 0)
            {
                baseFreq = 31250;
            }
            if (resourcePath == null)
            {
                int i = inputfile.LastIndexOfAny(new char[]{ '\\', '/' });
                if(i < 0)
                {
                    resourcePath = "";
                }
                else
                {
                    resourcePath = inputfile.Substring(0, i + 1);
                }
            }
            if (output && (outputfile == null))
            {
                int i = inputfile.LastIndexOf('.');
                if (i < 0)
                {
                    outputfile = inputfile + ".wav";
                }
                else
                {
                    outputfile = inputfile.Substring(0, i) + ".wav";
                }
            }

            string txt;
#if !DEBUG
            try
#endif
            {
                using (var sr = new System.IO.StreamReader(inputfile, Encoding.UTF8, true))
                {
                    txt = sr.ReadToEnd();
                }
            }
#if !DEBUG
            catch (Exception e)
            {
                return Exit(ExitCode.ReadFailed, e.Message);
            }
#endif

            MyMMLSequence mml = new MyMMLSequence(txt);
            if (mml.ErrorLine != 0)
            {
                return Exit(ExitCode.PaserError, "ParseFailed " + mml.ErrorLine + ":" + mml.ErrorPosition + ":" + mml.ErrorString + " <<<");
            }
#if !DEBUG
            try
#endif
            {
                bool canceled = false;
                if (play)
                {
                    canceled = playMML(numVoices, baseFreq, resourcePath, mml, volume, loop, Verbose);
                }
                if(output)
                {
                    if (freq == 0)
                    {
                        freq = 44100;
                    }
                    if (bps == 0)
                    {
                        bps = 2;
                    }
                    canceled = offlineRendering(outputfile, freq, bps, numVoices, baseFreq, resourcePath, mml, volume, Verbose);
                }
                if (canceled)
                {
                    HitAnyKey = false;
                }
            }
#if !DEBUG
            catch (System.Exception e)
            {
                return Exit(ExitCode.WriteFailed, e.Message);
            }
#endif
            return Exit(ExitCode.Ok, "Ok..");
        }
        static private void setup(string resourcePath, MyMixer Mixer, MyMMLSequencer Sequencer, MyMMLSequence Sequence, MySynthesizer [] Synthesizers, bool verbose)
        {
            if (verbose)
            {
                foreach (KeyValuePair<string, string> pair in Sequence.Property)
                {
                    WriteLine("<" + pair.Key + "> = " + pair.Value);
                }
            }
            for (int i = 0; i < Synthesizers.Length; i++)
            {
                if(Synthesizers[i] == null)
                {
                    continue;
                }
                List<object> toneSet = new List<object>();
                Dictionary<int, int> toneMap = new Dictionary<int, int>();
                for (int j = 0; j < Sequence.ToneData.Count; j++)
                {
                    if((Sequence.ToneMask[j] & (1 << i)) == 0)
                    {
                        continue;
                    }
                    object tone = Synthesizers[i].CreateToneObject(Sequence.ToneData[j]);
                    //tone = new MySpace.Synthesizer.PM8.ToneParam(); // dummy tone
                    if (tone != null)
                    {
                        if(tone is MySpace.Synthesizer.SS8.ToneParam)
                        {
                            MySpace.Synthesizer.SS8.ToneParam ssTone = tone as MySpace.Synthesizer.SS8.ToneParam;
                            string filename = ssTone.ResourceName + ".wav";
                            int ll = filename.LastIndexOfAny(new char[] { '\\', '/' });
                            if(ll >= 0)
                            {
                                filename = filename.Substring(ll);
                            }
                            float[] samples = loadMonaural(resourcePath + filename);
                            ssTone.SetSamples(samples);
                        }
                        if (verbose)
                        {
                            WriteLine("port" + i + " : Load toneData[" + Sequence.ToneName[j] + "] : <0x" + toneMap.Count.ToString("X2") + ">");
                        }
                        toneMap.Add(j, toneSet.Count);
                        toneSet.Add(tone);
                    }
                    else
                    {
                        if (!verbose)
                        {
                            Write("\n");
                        }
                        WriteLine("port" + i + " : Failed to load toneData[" + Sequence.ToneName[j] + "] : " + Sequence.ToneData[j]);
                    }
                }
                Sequencer.SetSynthesizer(i, Synthesizers[i], toneSet, toneMap, 0xffffffffU);
            }
            if (verbose)
            {
                Sequencer.AppDataEvent = (port, channel, trackNo, measureCount, tickCount, data) =>
                {
                    WriteLine(data);
                };
                Sequencer.PlayingEvent = (port, channel, trackNo, measureCount ,tickCount, step, gate, ist, sequence, sectionIndex, instructionIndex) =>
                {
#if !DEBUG
                    if(ist.N == InstructionNote.Rest)
                    {
                        return;
                    }
#endif
                    uint tb = 32;// 96;
                    var tc = tickCount * tb / Sequencer.TimeBase;
                    var st = step * tb / Sequencer.TimeBase;
                    var gt = gate * tb / Sequencer.TimeBase;
                    string str = "" +
                        trackNo.ToString("D2") + ":" + channel.ToString("D2") + " " +
                        measureCount.ToString("D3") + ":" +
                        tc.ToString("D3") + " " +
                        st.ToString("D3") + ":" +
                        gt.ToString("D3") + " ";
                    if ((int)ist.N == 0)
                    {
                        str += "" + ist.N;
                    }
                    else if ((int)ist.N < 128)
                    {
#if DEBUG
                        str += ((int)ist.N).ToString("D3") + " " + ist.V.ToString("D3");
#else
                        char c0 = "ccddeffggaab"[(int)ist.N % 12];
                        char c1 = " # #  # # # "[(int)ist.N % 12];
                        int oct = ((int)ist.N / 12) - 2;
                        str += "" + c0 + c1 + oct + " " + ist.V.ToString("D3");
#endif
                    }
                    else
                    {
                        str += "" + ist.N + " <0x" + (ist.V | ((int)ist.Q << 8)).ToString("X4") + ">";
                    }
                    WriteLine(str);
                };
            }
            Mixer.TickCallback += Sequencer.Tick;
        }
        static private bool playMML(uint numVoices, uint baseFreq, string resourcePath, MyMMLSequence mml, float volume, bool loop, bool verbose)
        {
            bool canceled = false;
            uint bufferSize = 200;      // msec
            MyMixer mix = new MyMixer(MySpace.DirectSound.MyDirectStream.Frequency, false, bufferSize, baseFreq);
            MyMMLSequencer seq = new MyMMLSequencer(mix.TickFrequency);
            MySynthesizer[] sss = new MySynthesizer[MyMMLSequence.MaxNumPorts];
            MyThread mth = new MyThread();
            mix.MasterVolume = volume;
            sss[0] = new MySynthesizerPM8(mix, numVoices);
            sss[1] = new MySynthesizerSS8(mix, numVoices);
            sss[2] = new MySynthesizerCT8(mix, numVoices);
            setup(resourcePath, mix, seq, mml, sss, verbose);
            seq.KeyShift = 0;
            seq.VolumeScale = 1.0f;
            seq.TempoScale = 1.0f;
            seq.Play(mml, 0.0f, loop);
            using (var mds = new MySpace.DirectSound.MyDirectStream())
            {
                mds.Play((data, numSamples) =>
                {
                    mix.Output(data, 2, numSamples);
                });
                mth.Start(mix.Update);
                while (seq.Playing)
                {
                    System.Threading.Thread.Sleep(16);
                    mth.Raise();
                    mds.Raise();
                    if (!canceled && Console.KeyAvailable)
                    {
                        var key = Console.ReadKey(true);
                        if(key.Key == ConsoleKey.Escape)
                        {
                            seq.Stop(1.0f);
                            canceled = true;
                        }
                    }
                }
                for (int i = 0; i < bufferSize / 16; i++)
                {
                    System.Threading.Thread.Sleep(16);
                    mth.Raise();
                    mds.Raise();
                }
                mds.Stop();
                mth.Stop();
            }
            foreach(MySynthesizer s in sss)
            {
                if (s != null)
                {
                    s.Terminate();
                }
            }
            mix.Terminate();
            return canceled;
        }
        static private bool offlineRendering(string outputfile, uint freq, uint bps, uint numVoices, uint baseFreq, string resourcePath, MyMMLSequence mml, float volume, bool verbose)
        {
            bool canceled = false;
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();
            using (var ww = new WaveWriter(outputfile, freq, bps))
            {
                MyMixer mix = new MyMixer(freq, true, 200, baseFreq);
                MyMMLSequencer seq = new MyMMLSequencer(mix.TickFrequency);
                MySynthesizer[] sss = new MySynthesizer[MyMMLSequence.MaxNumPorts];
                mix.MasterVolume = volume;
                sss[0] = new MySynthesizerPM8(mix, numVoices);
                sss[1] = new MySynthesizerSS8(mix, numVoices);
                sss[2] = new MySynthesizerCT8(mix, numVoices);
                setup(resourcePath, mix, seq, mml, sss, verbose);
                seq.KeyShift = 0;
                seq.VolumeScale = 1.0f;
                seq.TempoScale = 1.0f;
                seq.Play(mml, 0.0f, false);

                int sectorSize = 588;
                int count = 0;
                int seconds = 0;
                float[] sector = new float[sectorSize * 2];
                bool zeroCross = false;
                for (;;)
                {
                    if (seq.Playing)
                    {
                        mix.Update();
                        if (Console.KeyAvailable)
                        {
                            var key = Console.ReadKey(true);
                            if (key.Key == ConsoleKey.Escape)
                            {
                                canceled = true;
                                break;
                            }
                        }
                    }
                    Array.Clear(sector, 0, sector.Length);
                    int num = mix.Output(sector, 2, sectorSize);
                    if(num == 0)
                    {
                        if (!zeroCross)
                        {
                            mix.Update();
                            continue;
                        }
                        break;
                    }
                    float v0 = sector[(num - 1) * 2 + 0];
                    float v1 = sector[(num - 1) * 2 + 1];
                    zeroCross = (v0 == 0.0f) && (v1 == 0.0f);
                    ww.Write(sector, num);
                    count += num;
                    if (count > sectorSize * 75)
                    {
                        count %= sectorSize * 75;
                        seconds++;
                        if (!verbose)
                        {
                            Write(".");
                        }
                    }
                }
                if (count != 0)
                {
                    seconds++;
                }
                if (!verbose)
                {
                    Write("\n");
                }
                WriteLine("total output time is " + seconds + " seconds");
                ww.Close();
                mix.Terminate();
                foreach(MySynthesizer s in sss)
                {
                    if(s != null)
                    {
                        s.Terminate();
                    }
                }
            }
            sw.Stop();
            //WriteLine("caluculation time is " + (int)Math.Ceiling(sw.Elapsed.TotalSeconds) + " seconds");
            WriteLine("caluculation time is " + sw.Elapsed.TotalSeconds + " seconds");
            return canceled;
        }
        static float[] loadMonaural(string filePath)
        {
            WaveReader wr = new WaveReader(filePath);
            float[] samples = new float[wr.Samples];
            wr.Read(samples);
            if(wr.Channels != 1)
            {
                float[] mixed = new float[wr.Samples / wr.Channels];
                int idx = 0;
                for(int i = 0; i < mixed.Length; i++)
                {
                    float s = 0.0f;
                    for(int j = 0; j < wr.Channels; j++)
                    {
                        float v = samples[idx++];
                        s += v;
                    }
                    mixed[i] = s;
                }
                samples = mixed;
            }
            return samples;
        }
    }
    class WaveWriter : IDisposable
    {
        private bool disposed = false;
        private FileStream fileStream;
        private BinaryWriter binaryWriter;
        private long dataPos;
        private uint bps;
        /// <summary>8bit,16bit,24bit and 32bit float</summary>
        /// <param name="Path"></param>
        /// <param name="Freq"></param>
        /// <param name="BytesPerSample"></param>
        public WaveWriter(string Path, uint Freq, uint BytesPerSample)
        {
            bps = (BytesPerSample > 4) ? 2 : ((BytesPerSample == 0) ? 2 : BytesPerSample);
            fileStream = new FileStream(Path, FileMode.Create, FileAccess.Write);
            binaryWriter = new BinaryWriter(fileStream);

            binaryWriter.Write(new byte[4] { (byte)'R', (byte)'I', (byte)'F', (byte)'F' });
            binaryWriter.Write((UInt32)(4 + 4 + 4 + 2 + 2 + 4 + 4 + 2 + 2 + 4 + 4 + 0 * 2 * 2));   // size

            binaryWriter.Write(new byte[4] { (byte)'W', (byte)'A', (byte)'V', (byte)'E' });
            binaryWriter.Write(new byte[4] { (byte)'f', (byte)'m', (byte)'t', (byte)' ' });
            binaryWriter.Write((UInt32)(16));
            if (bps < 4)
            {
                binaryWriter.Write((UInt16)(1));            // format 1:linear pcm
            }
            else
            {
                binaryWriter.Write((UInt16)(3));            // format 3:32bit float
            }
            binaryWriter.Write((UInt16)(2));                // channels

            binaryWriter.Write((UInt32)(Freq));             // samples per sec
            binaryWriter.Write((UInt32)(Freq * bps * 2));   // bytes per sec
            binaryWriter.Write((UInt16)(bps * 2));          // bytes per sample * channels
            binaryWriter.Write((UInt16)(bps * 8));          // bits per sample

            binaryWriter.Write(new byte[4] { (byte)'d', (byte)'a', (byte)'t', (byte)'a' });
            binaryWriter.Write((UInt32)(0));
            dataPos = binaryWriter.Seek(0, SeekOrigin.Current);
        }
        ~WaveWriter()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool Disposing)
        {
            if (!this.disposed)
            {
                if (Disposing)
                {
                    this.Close();
                }
                this.disposed = true;
            }
        }
        public void Close()
        {
            if (fileStream != null)
            {
                long len = binaryWriter.Seek(0, SeekOrigin.Current);
                binaryWriter.Seek(4, SeekOrigin.Begin);
                binaryWriter.Write((UInt32)(len - 8));
                binaryWriter.Seek((int)(dataPos - 4), SeekOrigin.Begin);
                binaryWriter.Write((UInt32)(len - dataPos));
                binaryWriter.Close();
                binaryWriter = null;
                fileStream.Close();
                fileStream = null;
            }
        }
        public void Write(float[] StereoSamples, int NumSamples)
        {
            for (int i = 0; i < NumSamples * 2; i++)
            {
                float v = StereoSamples[i];
                v = (v < -1.0f) ? -1.0f : (v > +1.0f ? +1.0f : v);
                switch (bps)
                {
                    case 1:
                        {
                            Byte d = (Byte)(v * ((1 << 7) - 1) + 128.0f);
                            binaryWriter.Write(d);
                        }
                        break;
                    default:
                    case 2:
                        {
                            Int16 d = (Int16)(v * ((1 << 15) - 1));
                            binaryWriter.Write(d);
                        }
                        break;
                    case 3:
                        {
                            Int32 d = (Int32)(v * ((1 << 23) - 1));
                            binaryWriter.Write((Byte)((d >> 0) & 0xffU));
                            binaryWriter.Write((Byte)((d >> 8) & 0xffU));
                            binaryWriter.Write((Byte)((d >> 16) & 0xffU));
                        }
                        break;
                    case 4:
                        binaryWriter.Write(v);
                        break;
                }
            }
        }
    }
    class WaveReader : IDisposable
    {
        private bool disposed = false;
        private FileStream fileStream;
        private BinaryReader binaryReader;
        private int dataPos;
        private int dataNum;
        public int Channels { get; private set; }
        public int Frequency { get; private set; }
        public int Samples { get; private set; }
        private int bps;
        private void checkTag(byte[] id)
        {
            byte[] read = binaryReader.ReadBytes(id.Length);
            for(int i = 0; i < id.Length; i++)
            {
                if(read[i] != id[i])
                {
                    throw new System.Exception("tag error : <" + read + "> != <" + id + ">");
                }
            }
        }
        /// <param name="Path"></param>
        public WaveReader(string Path)
        {
            fileStream = new FileStream(Path, FileMode.Open, FileAccess.Read);
            binaryReader = new BinaryReader(fileStream);

            checkTag(new byte[4] { (byte)'R', (byte)'I', (byte)'F', (byte)'F' });
            UInt32 size = binaryReader.ReadUInt32();

            checkTag(new byte[4] { (byte)'W', (byte)'A', (byte)'V', (byte)'E' });

            checkTag(new byte[4] { (byte)'f', (byte)'m', (byte)'t', (byte)' ' });
            UInt32 fmtSize = binaryReader.ReadUInt32();     // (UInt32)(16));
            UInt16 format = binaryReader.ReadUInt16();      // 1:linear pcm, 3:32bit float
            UInt16 channels = binaryReader.ReadUInt16();
            UInt32 sampleRate = binaryReader.ReadUInt32();
            UInt32 bytesPerSec = binaryReader.ReadUInt32();
            UInt16 blockSize = binaryReader.ReadUInt16();
            UInt16 bitsPerSample = binaryReader.ReadUInt16();
            if (fmtSize > 16)
            {
                binaryReader.ReadBytes((int)fmtSize - 16);
            }
            Frequency = (int)sampleRate;
            Channels = (int)channels;
            bps = blockSize / channels;
            switch (format)
            {
                case 1:
                    if ((bitsPerSample != 8) && (bitsPerSample != 16) && (bitsPerSample != 24))
                    {
                        throw new System.Exception("Unknown format id=" + format + " bps=" + bitsPerSample);
                    }
                    break;
                case 3:
                    if (bitsPerSample != 32)
                    {
                        throw new System.Exception("Unknown format id=" + format + " bps=" + bitsPerSample);
                    }
                    break;
                default:
                    throw new System.Exception("Format id=" + format + " : not supported");
            }

            for (;;)
            {
                byte[] chunkTag = binaryReader.ReadBytes(4);
                if (chunkTag.SequenceEqual(new byte[4] { (byte)'d', (byte)'a', (byte)'t', (byte)'a' }))
                {
                    break;
                }
                UInt32 chunkSize = binaryReader.ReadUInt32();
                binaryReader.ReadBytes((int)chunkSize);
            }
            UInt32 dataSize = binaryReader.ReadUInt32();
            dataPos = 0;
            dataNum = (int)dataSize / (bitsPerSample / 8);
            Samples = dataNum;
        }
        ~WaveReader()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool Disposing)
        {
            if (!this.disposed)
            {
                if (Disposing)
                {
                    this.binaryReader.Close();
                    this.binaryReader = null;
                    this.fileStream.Close();
                    this.fileStream = null;
                }
                this.disposed = true;
            }
        }
        public void Close()
        {
            Dispose();
        }
        public int Read(float[] Samples)
        {
            int num = 0;
            for (int i = 0; i < Samples.Length; i++)
            {
                if (dataPos >= dataNum)
                {
                    Samples[i] = 0.0f;
                }
                else
                {
                    num++;
                    switch (bps)
                    {
                        case 1:
                            Samples[i] = (binaryReader.ReadByte() - 128.0f) * (1.0f / SByte.MaxValue);
                            break;
                        case 2:
                            Samples[i] = (binaryReader.ReadInt16()) * (1.0f / Int16.MaxValue);
                            break;
                        case 3:
                            {
                                byte[] val = binaryReader.ReadBytes(3);
                                Int32 v = ((Int32)val[0] << 8) | ((Int32)val[1] << 16) | ((Int32)val[2] << 24);
                                Samples[i] = v * (1.0f / Int32.MaxValue);
                            }
                            break;
                        case 4:
                            Samples[i] = binaryReader.ReadSingle();
                            break;
                    }
                    dataPos++;
                }
            }
            return num / Channels;
        }
    }
}
