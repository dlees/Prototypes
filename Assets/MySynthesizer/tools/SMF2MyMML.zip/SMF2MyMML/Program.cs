﻿using System;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

using MySpace.Synthesizer.MMLSequencer;
using MySpace;

namespace SMF2MyMML
{
    class Program
    {
        private static void WriteLine(string str)
        {
            Debug.WriteLine(str);
            Console.WriteLine(str);
        }
        private static void Write(string str)
        {
            Debug.Write(str);
            Console.Write(str);
        }
        enum ExitCode
        {
            Ok = 0,
            Usage = -1,
            ReadFailed = -2,
            PaserError = -3,
            WriteFailed = -4,
            IllegalData = -5,
        }
        static private bool Verbose = false;
        static private bool HitAnyKey = false;
        private static void Exit(ExitCode ec, string message)
        {
            WriteLine(message);
            if (HitAnyKey)
            {
                WriteLine("HIT ANY KEY!");
                Console.ReadKey();
            }
            Environment.Exit((int)ec);
        }
        static int Main(string[] args)
        {
            //Debug.Listeners.Add(new TextWriterTraceListener(Console.Out));
            bool error = false;
            string outputFile = null;
            string inputFile = null;
            string toneMapFile = null;
            string drumMapFile = null;
            bool useDrmMap = true;
            uint port = 2;
            Encoding enc = null;
            var ct = StringComparison.CurrentCultureIgnoreCase;
            for (int i = 0; i < args.Length; i++)
            {
                var s = args[i];
                if (s[0] != '-')
                {
                    if (inputFile != null)
                    {
                        error = true;
                    }
                    inputFile = s;
                }
                else if (s.Equals("-v", ct) || s.Equals("-verbose", ct))
                {
                    Verbose = true;
                }
                else if (s.Equals("-h", ct) || s.Equals("-hit", ct))
                {
                    HitAnyKey = true;
                }
                else if (s.Equals("-nd", ct) || s.Equals("-nodrum", ct))
                {
                    useDrmMap = false;
                }
                else if (s.Equals("-p", ct) || s.Equals("-port", ct))
                {
                    if (((i + 1) < args.Length) && uint.TryParse(args[++i], out port))
                    {
                        if (port > 3)
                        {
                            error = true;
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-o", ct) || s.Equals("-output", ct))
                {
                    if (outputFile != null)
                    {
                        error = true;
                    }
                    if ((i + 1) < args.Length)
                    {
                        outputFile = args[++i];
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-t", ct) || s.Equals("-tonemap", ct))
                {

                    if (toneMapFile != null)
                    {
                        error = true;
                    }
                    if ((i + 1) < args.Length)
                    {
                        toneMapFile = args[++i];
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-d", ct) || s.Equals("-drummap", ct))
                {
                    if (drumMapFile != null)
                    {
                        error = true;
                    }
                    if ((i + 1) < args.Length)
                    {
                        drumMapFile = args[++i];
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-e", ct) || s.Equals("-encoding", ct))
                {
                    if (enc != null)
                    {
                        error = true;
                    }
                    int codePage;
                    if (((i + 1) < args.Length) && int.TryParse(args[++i], out codePage))
                    {
                        enc = System.Text.Encoding.GetEncoding(codePage);
                    }
                    else
                    {
                        error = true;
                    }
                }
                else
                {
                    error = true;
                }
            }
            if (error || (inputFile == null))
            {
                Exit(ExitCode.Usage, "usage:\n" +
                    "> SMF2MyMML input.mid [-v] [-h] [-e 65001] [-p 2] [-o input.mml.txt] [-t ct8tone.mml.txt] [-d ct8drum.mml.txt] [-nd]\n" +
                    "-v: Verbose\n" +
                    "-h: Hit Any Key!\n" +
                    "-e: Code page ex.932=sjis,65001=utf8\n" +
                    "-p: Port (0~3)\n" +
                    "-o: Output to file\n" +
                    "-t: Tone map ex.\"$@(prg001)=ttt\" 001~128\n" +
                    "-d: Drum map ex.\"$@(xxx)=ttt\\n$(drm000)=$@(xxx)\" 000~127\n" +
                    "-nd: Don't use ch10 for drum part"
                    );
            }
            if(outputFile == null)
            {
                int dot = inputFile.LastIndexOf('.');
                if(dot >= 0)
                {
                    outputFile = inputFile.Substring(0, inputFile.LastIndexOf('.'));
                }
                else
                {
                    outputFile = inputFile;
                }
                outputFile += ".mml.txt";
            }
            if(enc == null)
            {
                enc = System.Text.Encoding.UTF8;
            }
            MyMMLSequence toneMap = null;
#if true
            toneMap = LoadMML((toneMapFile != null) ? toneMapFile : "ct8tone.mml.txt");
            if (toneMap.ToneData.Count == 0)
            {
                Exit(ExitCode.IllegalData, "error: No tone data: " + toneMapFile);
            }
#else
            if (toneMapFile != null)
            {
                toneMap = LoadMML(toneMapFile);
                if(toneMap.ToneData.Count == 0)
                {
                    Exit(ExitCode.IllegalData, "error: No tone data: " + toneMapFile);
                }
            }
            else
            {
                toneMap = LoadMMLFromResource("tone.mml.txt");
            }
#endif
            MyMMLSequence drumMap = null;
#if true
            drumMap = LoadMML((drumMapFile != null) ? drumMapFile : "ct8drum.mml.txt");
            if (drumMap.ToneData.Count == 0)
            {
                Exit(ExitCode.IllegalData, "error: No tone data: " + drumMapFile);
            }
#else
            if (drumMapFile != null)
            {
                drumMap = LoadMML(drumMapFile);
                if (drumMap.ToneData.Count == 0)
                {
                    Exit(ExitCode.IllegalData, "error: No tone data: " + drumMapFile);
                }
            }
            else
            {
                drumMap = LoadMMLFromResource("drum.mml.txt");
            }
#endif
            MySpace.SMF2MyMML.ToneDataSet toneDataSet = new MySpace.SMF2MyMML.ToneDataSet();
            toneBind(toneDataSet, toneMap);
            drumBind(toneDataSet, drumMap);
#if !DEBUG
            try
#endif
            {
                using (StreamWriter mml = new StreamWriter(outputFile, false, Encoding.UTF8))
                using (SMFReader smf = new SMFReader(inputFile))
                {
                    MySpace.SMF2MyMML smf2mml = new MySpace.SMF2MyMML(smf, mml, enc, useDrmMap);
                    smf2mml.Verbose = Verbose;
                    smf2mml.Output += WriteLine;
                    smf2mml.Do(inputFile, toneDataSet, port);
                }
            }
#if !DEBUG
            catch (System.Exception e)
            {
                Exit(ExitCode.WriteFailed, e.Message);
            }
#endif
            Exit(ExitCode.Ok, "Ok..");
            return 0;
        }
        private static void toneBind(MySpace.SMF2MyMML.ToneDataSet toneDataSet, MyMMLSequence toneMap)
        {
            var nameList = toneMap.ToneName;
            var dataList = toneMap.ToneData;
            var tag = "prg";
            for (int i = 0; i < nameList.Count; i++)
            {
                string name = nameList[i];
                if (name.Length <= tag.Length)
                {
                    continue;
                }
                if (!name.Substring(0, tag.Length).Equals(tag, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                int num;
                if (!int.TryParse(name.Substring(tag.Length), out num))
                {
                    continue;
                }
                if ((num < 1) || (num > 128))
                {
                    continue;
                }
                toneDataSet.prgData[num - 1] = "$@(" + tag + num.ToString("D3") + ") = " + dataList[i];
            }
        }
        private static void drumBind(MySpace.SMF2MyMML.ToneDataSet toneDataSet, MyMMLSequence drumMap)
        {
            Regex prgRex = new Regex(@"@\(([^()]*)\)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            for (int i = 0; i < 128; i++)
            {
                string name = "drm" + i.ToString("d3");
                string data;
                if (!drumMap.Macro.TryGetValue(name, out data))
                {
                    continue;
                }
                var prgs = prgRex.Matches(data);
                if (prgs.Count != 1)
                {
                    continue;
                }
                toneDataSet.drmMacro[i] = new Tuple<string, string>("$(" + name + ") = " + data, prgs[0].Groups[1].Value);
            }
            for (int i = 0; i < drumMap.ToneName.Count; i++)
            {
                toneDataSet.drmData.Add(drumMap.ToneName[i], "$@(" + drumMap.ToneName[i] + ") = " + drumMap.ToneData[i]);
            }
        }
        private static MyMMLSequence LoadMML(string path)
        {
            MyMMLSequence mml = null;
#if !DEBUG
            try
#endif
            {
                string txt;
                using (var sr = new StreamReader(path, Encoding.UTF8, true))
                {
                    txt = sr.ReadToEnd();
                }
                mml = new MyMMLSequence(txt);
                if (mml.ErrorLine != 0)
                {
                    Exit(ExitCode.PaserError, "ParseFailed : " + path + ": " + mml.ErrorLine + ":" + mml.ErrorPosition + ":" + mml.ErrorString + " <<<");
                }
            }
#if !DEBUG
            catch (Exception e)
            {
                Exit(ExitCode.ReadFailed, e.Message);
            }
#endif
            return mml;
        }
        private static MyMMLSequence LoadMMLFromResource(string path)
        {
            MyMMLSequence mml = null;
#if !DEBUG
            try
#endif
            {
                string txt;
                Assembly assembly = Assembly.GetExecutingAssembly();
                using (var sr = new StreamReader(assembly.GetManifestResourceStream("SMF2MyMML." + path)))
                {
                    txt = sr.ReadToEnd();
                }
                mml = new MyMMLSequence(txt);
                if (mml.ErrorLine != 0)
                {
                    Exit(ExitCode.PaserError, "ParseFailed : SMF2MyMML." + path + ": " + mml.ErrorLine + ":" + mml.ErrorPosition + ":" + mml.ErrorString + " <<<");
                }
            }
#if !DEBUG
            catch (Exception e)
            {
                Exit(ExitCode.ReadFailed, e.Message);
            }
#endif
            return mml;
        }
    }
}
