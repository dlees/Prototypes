﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace MySpace
{
    public class SMF2MyMML
    {
        private SMFReader smf;
        private StreamWriter mml;
        private Encoding enc;
        private bool useDrumMap;
        private readonly StringBuilder builder = new StringBuilder();

        public bool Verbose
        {
            get;
            set;
        }
        public event Action<string> Output;

        public void Write(string frm, params object[] args)
        {
            if (Output == null)
            {
                return;
            }
            {
                builder.AppendFormat(frm, args);
                var str = builder.ToString().Split('\n');
                for (int i = 0; i < str.Length - 1; i++)
                {
                    Output.Invoke(str[i]);
                }
                builder.Remove(0, builder.Length);
                builder.Append(str[str.Length - 1]);
            }
        }
        public void WriteLine(string frm, params object[] args)
        {
            if (Output == null)
            {
                return;
            }
            {
                if(frm == null)
                {
                    frm = "\n";
                }
                builder.AppendFormat(frm, args);
                var str = builder.ToString().Split('\n');
                for (int i = 0; i < str.Length; i++)
                {
                    Output.Invoke(str[i]);
                }
                builder.Remove(0, builder.Length);
            }
        }

        public SMF2MyMML(SMFReader Smf, StreamWriter Mml, Encoding Encoding, bool UseDrumMap)
        {
            smf = Smf;
            mml = Mml;
            enc = Encoding;
            useDrumMap = UseDrumMap;
        }
        private void mmlWriteLine(string str = null)
        {
#if true//DEBUG
            if (Verbose)
            {
                WriteLine(str);
            }
#endif
            mml.WriteLine(str);
        }
        private void mmlWrite(string str)
        {
#if true//DEBUG
            if (Verbose)
            {
                Write(str);
            }
#endif
            mml.Write(str);
        }
        private class MidiEvent
        {
            public uint flags;
            public uint step;
            public uint length;
            public uint value;
            public byte state;
            public byte arg0;
            public byte arg1;
            public byte[] opt;
            public MidiEvent(uint step, byte state, byte arg0, byte arg1, uint flags, byte[] opt = null, uint value = 0)
            {
                this.flags = flags;
                this.step = step;
                this.length = 0;
                this.value = value;
                this.state = state;
                this.arg0 = arg0;
                this.arg1 = arg1;
                this.opt = opt;
            }
        }
        private List<MidiEvent> systemEvent = new List<MidiEvent>();
        private class MidiTrackInfo
        {
            public uint step;
            public MidiChannelInfo[] channel;
        }
        private class MidiChannelInfo
        {
            public int channelNumber;
            public int messageCount;
            public int assignedTrackNumber;
            public List<MidiEvent> midiEvent = new List<MidiEvent>();
            public Dictionary<byte, int> midiEventIndex = new Dictionary<byte, int>();
        }
        private class MmlTrackInfo
        {
            public int index;
            public class NoteInfo
            {
                public byte state;
                public byte number;
                public byte velocity;
                public uint goff;
                public uint gend;
                public uint flags;
            }
            public byte programNo;
            public LinkedList<NoteInfo> notes;
            public MidiChannelInfo midiChannel;
        }
        private MidiTrackInfo[] midiTrack;
        private MmlTrackInfo[] mmlTrack;
        public class ToneDataSet
        {
            public readonly string[] prgData = new string[128];
            public readonly Tuple<string, string>[] drmMacro = new Tuple<string, string>[128];
            public readonly Dictionary<string, string> drmData = new Dictionary<string, string>();
        }
        private void setupHeader(string Title, ToneDataSet ToneDataSet, uint Port)
        {
            bool[] prgUsing = new bool[128];
            bool[] drmUsing = new bool[128];
            Dictionary<string, string> drmData = new Dictionary<string, string>();

            mmlWriteLine("/*");
            mmlWriteLine(" * " + Title);
            mmlWriteLine(" * " + DateTime.Now.ToString());
            mmlWriteLine(" */");
            mmlWriteLine("");

            midiTrack = new MidiTrackInfo[smf.Tracks.Count];
            for (int i = 0; i < smf.Tracks.Count; i++)
            {
                midiTrack[i] = new MidiTrackInfo();
                midiTrack[i].channel = new MidiChannelInfo[16];
                for (int j = 0; j < 16; j++)
                {
                    midiTrack[i].channel[j] = new MidiChannelInfo();
                    midiTrack[i].channel[j].channelNumber = j;
                }
                for (int j = 0; j < smf.Tracks[i].Count; j++)
                {
                    SMFReader.MidiEvent evt = smf.Tracks[i][j];
                    // 00-7f: note
                    // 80-ef channel message
                    if (evt.state < 0xf0)
                    {
                        midiTrack[i].channel[evt.state & 0xf].messageCount++;
                    }
                    // ch10 note on == drum
                    if ((evt.state == 0x99) && useDrumMap)
                    {
                        drmUsing[evt.arg0] = true;
                    }
                    // c0-cf: progrm change except ch10
                    if ((evt.state >= 0xc0) && (evt.state <= 0xcf) && ((evt.state != 0xc9) || !useDrumMap))
                    {
                        prgUsing[evt.arg0] = true;
                    }
                    // informations
                    if (evt.state == 0xff)
                    {
                        switch (evt.arg0)
                        {
                            default:
                            case 0x00:
                                break;
                            case 0x01:
                                mmlWriteLine("$<Comments> = " + enc.GetString(evt.opt));
                                break;
                            case 0x02:
                                mmlWriteLine("$<Copyright> = " + enc.GetString(evt.opt));
                                break;
                            case 0x03:
                                if (i == 0)
                                {
                                    mmlWriteLine("$<Title> = " + enc.GetString(evt.opt));
                                }
                                else
                                {
                                    mmlWriteLine("$<Track" + i.ToString("D2") + "> = " + enc.GetString(evt.opt));
                                }
                                break;
                        }
                    }
                }
            }
            mmlWriteLine();

            for (int i = 0; i < 128; i++)
            {
                if (prgUsing[i])
                {
                    mmlWriteLine(ToneDataSet.prgData[i]);
                }
            }
            for (int i = 0; i < 128; i++)
            {
                if (drmUsing[i])
                {
                    string data;
                    if (ToneDataSet.drmData.TryGetValue(ToneDataSet.drmMacro[i].Item2, out data))
                    {
                        drmData[ToneDataSet.drmMacro[i].Item1] = data;
                    }
                }
            }
            mmlWriteLine();

            foreach (var data in drmData)
            {
                mmlWriteLine(data.Value);
            }

            mmlWriteLine();
            for (int i = 0; i < 128; i++)
            {
                if (drmUsing[i])
                {
                    mmlWriteLine(ToneDataSet.drmMacro[i].Item1);
                }
            }

            mmlWriteLine();

            int trackNumber = 0;
            for (int i = 0; i < midiTrack.Length; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    if (midiTrack[i].channel[j].messageCount != 0)
                    {
                        midiTrack[i].channel[j].assignedTrackNumber = trackNumber++;
                        if (trackNumber > 99)
                        {
                            throw new System.Exception("too mutch channels x tracks.");
                        }
                        mmlWriteLine("$t" + midiTrack[i].channel[j].assignedTrackNumber.ToString("D2") + " = " + Port.ToString() + ":" + j);
                    }
                }
            }
            mmlWriteLine("");
            mmlTrack = new MmlTrackInfo[trackNumber];
        }
        private uint convertStepFloor(uint step)
        {
            return step * 32 / smf.TimeDivision;
        }
        private uint convertStepCeil(uint step)
        {
            return (step * 32 + smf.TimeDivision - 1) / smf.TimeDivision;
        }
        private void prepareTracks()
        {
            for (int i = 0; i < smf.Tracks.Count; i++)
            {
                uint rpnl = 0;
                uint rpnm = 0;
                uint tune = 0;
                uint bend = 0x200U;
                uint flags = 0;
                for (int j = 0; j < smf.Tracks[i].Count; j++)
                {
                    var ev = smf.Tracks[i][j];
                    uint cn = (uint)ev.state & 0x0fU;
                    uint st = (uint)ev.state >> 4;
                    midiTrack[i].step += ev.delta;
                    if (st == 0x9)
                    {
                        // note on
                        var ch = midiTrack[i].channel[cn];
                        int idx;
                        var note = ev.arg0;
                        var velocity = ev.arg1;
                        if (ch.midiEventIndex.TryGetValue(note, out idx))
                        {
                            ch.midiEventIndex.Remove(note);
                            ch.midiEvent[idx].length = convertStepCeil(midiTrack[i].step) - ch.midiEvent[idx].step;
                            ch.midiEvent[idx].flags = (ch.midiEvent[idx].flags & ~1U) | (flags & 1U);
                        }
                        if (velocity != 0)
                        {
                            ch.midiEventIndex.Add(note, ch.midiEvent.Count);
                            ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, note, velocity, flags));
                        }
                    }
                    else if (st == 0x8)
                    {
                        // note off
                        var ch = midiTrack[i].channel[cn];
                        int idx;
                        var note = ev.arg0;
                        if (ch.midiEventIndex.TryGetValue(note, out idx))
                        {
                            ch.midiEventIndex.Remove(note);
                            ch.midiEvent[idx].length = convertStepCeil(midiTrack[i].step) - ch.midiEvent[idx].step;
                            ch.midiEvent[idx].flags = (ch.midiEvent[idx].flags & ~1U) | (flags & 1U);
                        }
                    }
                    else if (st == 0xa)
                    {
                        // polyphonic key pressure
                        var ch = midiTrack[i].channel[cn];
                        int idx;
                        var note = ev.arg0;
                        var velocity = ev.arg1;
                        if (ch.midiEventIndex.TryGetValue(note, out idx))
                        {
                            ch.midiEventIndex.Remove(note);
                            ch.midiEvent[idx].length = convertStepCeil(midiTrack[i].step) - ch.midiEvent[idx].step;
                            if (velocity != 0)
                            {
                                ch.midiEvent[idx].state = 0xa;
                                ch.midiEventIndex.Add(note, ch.midiEvent.Count);
                                ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)0x9, note, velocity, flags));
                            }
                        }
                    }
                    else if (st == 0xb)
                    {
                        // control change
                        var ch = midiTrack[i].channel[cn];
                        switch (ev.arg0)
                        {
                            case 0x41:  // portament
                                {
                                    flags = (flags & ~1U) | ((ev.arg1 >= 64) ? 1U : 0U);
                                }
                                break;
                            case 0x54:  // portament control
                                {
                                    ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, ev.arg1, 0, flags));
                                }
                                break;
                            case 0x64:  // rpn lsb
                                {
                                    rpnl = ev.arg1;
                                }
                                break;
                            case 0x65:  // rpn msb
                                {
                                    rpnm = ev.arg1;
                                }
                                break;
                            case 0x06:  // data entry msb
                                if ((rpnm == 0x00) && (rpnl == 0x00))
                                {
                                    // pitchbend sens
                                    bend = (bend & 0x00ffU) | ((uint)ev.arg1 << 8);
                                    ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, 0x80, ev.arg1, flags, null, bend));
                                }
                                else if ((rpnm == 0x00) && (rpnl == 0x01))
                                {
                                    // fine tune
                                    tune = (tune & 0x00ffU) | ((uint)ev.arg1 << 8);
                                    ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, 0x81, ev.arg1, flags, null, tune));
                                }
                                break;
                            case 0x26:  // data entry lsb
                                if ((rpnm == 0x00) && (rpnl == 0x00))
                                {
                                    // pitchbend sens
                                    bend = (bend & 0xff00U) | ((uint)ev.arg1 << 0);
                                    ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, 0x80, ev.arg1, flags, null, bend));
                                }
                                else if ((rpnm == 0x00) && (rpnl == 0x01))
                                {
                                    // fine tune
                                    tune = (tune & 0xff00U) | ((uint)ev.arg1 << 0);
                                    ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, 0x81, ev.arg1, flags, null, tune));
                                }
                                break;
                            case 0x01:  // modulation
                            case 0x05:  // portament time
                            case 0x07:  // channel volume
                            case 0x0a:  // pan
                            case 0x0b:  // expression
                            case 0x40:  // hold
                                {
                                    ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, ev.arg0, ev.arg1, flags));
                                }
                                break;
                            default:
                                {
                                    if (Verbose)
                                    {
                                        WriteLine(midiTrack[i].step.ToString("d8") + ":" + ev.state.ToString("X2") + ":" + ev.arg0.ToString("X2") + ":" + ev.arg1.ToString("X2") + " unsupported");
                                    }
                                }
                                break;
                        }
                    }
                    else if (st == 0xc)
                    {
                        // program change
                        var ch = midiTrack[i].channel[cn];
                        ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, ev.arg0, ev.arg1, flags));
                    }
                    else if (st == 0xd)
                    {
                        // channel pressure
                        var ch = midiTrack[i].channel[cn];
                        var oldIndex = ch.midiEventIndex;
                        ch.midiEventIndex = new Dictionary<byte, int>();
                        var velocity = ev.arg0;
                        foreach (var iidx in oldIndex)
                        {
                            var idx = iidx.Value;
                            var note = iidx.Key;
                            ch.midiEvent[idx].length = convertStepCeil(midiTrack[i].step) - ch.midiEvent[idx].step;
                            if (velocity != 0)
                            {
                                ch.midiEvent[idx].state = 0xd;
                                ch.midiEventIndex.Add(note, ch.midiEvent.Count);
                                ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)0x9, note, velocity, flags));
                            }
                        }
                    }
                    else if (st == 0xe)
                    {
                        // pitch bend
                        var ch = midiTrack[i].channel[cn];
                        ch.midiEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), (byte)st, ev.arg0, ev.arg1, flags));
                    }
                    else if (st == 0xf)
                    {
                        if ((cn == 0x0) || (cn == 0x7))
                        {
                            // system exclusive
                            if (Verbose)
                            {
                                WriteLine(midiTrack[i].step.ToString("d8") + ":" + ev.state.ToString("X2") + ":" + ev.arg0.ToString("X2") + ":" + ev.arg1.ToString("X2") + " unsupported");
                            }
                        }
                        else if (cn == 0xf)
                        {
                            switch (ev.arg0)
                            {
                                case 0x51:  // tempo
                                    {
                                        systemEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), ev.state, ev.arg0, ev.arg1, flags, ev.opt));
                                    }
                                    break;
                                case 0x58:  // time signature
                                    {
                                        systemEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), ev.state, ev.arg0, ev.arg1, flags, ev.opt));
                                    }
                                    break;
                                case 0x59:  // key signature
                                    {
                                        systemEvent.Add(new MidiEvent(convertStepFloor(midiTrack[i].step), ev.state, ev.arg0, ev.arg1, flags, ev.opt));
                                    }
                                    break;
                                case 0x00:  // sequence number
                                case 0x01:  // text event
                                case 0x02:  // copyright notice
                                case 0x03:  // sequence/track name
                                case 0x04:  // instrument name
                                case 0x05:  // lyric
                                case 0x06:  // marker
                                case 0x07:  // cue point
                                case 0x2f:  // end of track
                                    break;
                                case 0x7f:  // sequencer specific meta event
                                default:
                                    {
                                        if (Verbose)
                                        {
                                            WriteLine(midiTrack[i].step.ToString("d8") + ":" + ev.state.ToString("X2") + ":" + ev.arg0.ToString("X2") + ":" + ev.arg1.ToString("X2") + " unsupported");
                                        }
                                    }
                                    break;
                            }
                        }
                        else
                        {
                            if (Verbose)
                            {
                                WriteLine(midiTrack[i].step.ToString("d8") + ":" + ev.state.ToString("X2") + ":" + ev.arg0.ToString("X2") + ":" + ev.arg1.ToString("X2") + " unsupported");
                            }
                        }
                    }
                }
                foreach (var ch in midiTrack[i].channel)
                {
                    if (ch.messageCount != 0)
                    {
                        mmlTrack[ch.assignedTrackNumber] = new MmlTrackInfo();
                        mmlTrack[ch.assignedTrackNumber].midiChannel = ch;
                        mmlTrack[ch.assignedTrackNumber].programNo = 255;
                        mmlTrack[ch.assignedTrackNumber].notes = new LinkedList<MmlTrackInfo.NoteInfo>();
                    }
                    foreach (var idx in ch.midiEventIndex.Values)
                    {
                        ch.midiEvent[idx].length = convertStepCeil(midiTrack[i].step) - ch.midiEvent[idx].step;
                    }
                    ch.midiEventIndex.Clear();
                }

            }
        }
        private uint calcLen(uint dt, uint md, out uint len, out uint qtg)
        {
            int l;
            for (l = 0; l < 7; l++)
            {
                if (md < (1U << (l + 1)))
                {
                    break;
                }
                if (dt <= (1U << l))
                {
                    break;
                }
            }
            uint dx = (1U << l);
            len = 1U << (7 - l);
            qtg = (dt < dx) ? (dt * 128 / dx) : 128;
            return dx;
        }
        private uint calcLen(uint dt, out uint len)
        {
            int l;
            for (l = 0; l < 7; l++)
            {
                if (dt < (1U << (l + 1)))
                {
                    break;
                }
            }
            uint dx = (1U << l);
            len = 1U << (7 - l);
            return dx;
        }
        private void mmlWriteNote(MmlTrackInfo t, MmlTrackInfo.NoteInfo n, uint st, uint ed, bool tie)
        {
            uint dt = ((n.goff < ed) ? n.goff : ed) - st;
            uint l;
            uint q;
            uint dx;
            if (tie)
            {
                dx = calcLen(dt, out l);
                q = 128;
            }
            else
            {
                dx = calcLen(dt, ed - st, out l, out q);
            }
            Debug.Assert(n.gend == st);
            n.gend = st + dx;
            Debug.Assert(n.gend <= ed);
            if ((t.midiChannel.channelNumber == 0x9) && useDrumMap)
            {
                mmlWrite(string.Format("$(drm{0})", n.number.ToString("D3")));
                mmlWrite(string.Format("{0},{1},{2}", l, q, n.velocity));
            }
            else
            {
                mmlWrite(string.Format("n{0},{1},{2},{3}", n.number, l, q, n.velocity));
            }
        }
        private void mmlWriteRest(MmlTrackInfo t, MmlTrackInfo.NoteInfo n, uint st, uint ed)
        {
            uint dt = ((n.goff < ed) ? n.goff : ed) - st;
            uint l;
            uint dx = calcLen(dt, out l);
            Debug.Assert(n.gend == st);
            n.gend = st + dx;
            Debug.Assert(n.gend <= ed);
            mmlWrite(string.Format("r{0}", l));
        }
        private bool putMidiEvents(MmlTrackInfo t, LinkedListNode<MmlTrackInfo.NoteInfo> nn, uint st, uint ed, ref bool progress)
        {
            while (t.index < t.midiChannel.midiEvent.Count)
            {
                var ev = t.midiChannel.midiEvent[t.index];
                if (ev.step != st)
                {
                    break;
                }
                t.index++;
                switch (ev.state)
                {
                    case 0x9:   // note on
                    case 0xa:
                    case 0xd:
                        {
                            var n = new MmlTrackInfo.NoteInfo();
                            n.state = ev.state;
                            n.number = ev.arg0;
                            n.velocity = ev.arg1;
                            n.goff = st + ev.length;
                            n.gend = st;
                            n.flags = ev.flags;
                            if (nn != null)
                            {
                                nn.Value = n;
                            }
                            else
                            {
                                t.notes.AddLast(n);
                            }
                            if (progress)
                            {
                                mmlWrite(":");
                            }
                            mmlWriteNote(t, n, st, ed, ev.state != 0x9);
                            if ((n.gend < n.goff) || (ev.state != 0x9))
                            {
                                mmlWrite("^");
                            }
                            progress = true;
                            return true;
                        }
                    //break;
                    case 0xb:   // control change
                        {
                            string put = null;
                            switch (ev.arg0)
                            {
                                case 0x01: // modulation
                                    put = string.Format("@m{0}", ev.arg1);
                                    break;
                                case 0x05: // portament time
                                    put = string.Format("@pt{0}", ev.arg1);
                                    break;
                                case 0x07: // channel volume
                                    put = string.Format("@v{0}", ev.arg1);
                                    break;
                                case 0x0a: // pan
                                    put = string.Format("@pp{0}", ev.arg1);
                                    break;
                                case 0x0b: // expression
                                    put = string.Format("@e{0}", ev.arg1);
                                    break;
                                case 0x40: // hold
                                    put = string.Format("@d{0}", ev.arg1);
                                    break;
                                case 0x80: // bendrange
                                    put = string.Format("@br{0}", ev.value >> 8);
                                    break;
                                case 0x81: // finetune
                                    put = string.Format("@tn{0}", ev.value);
                                    break;
                            }
                            if (put != null)
                            {
                                if (progress)
                                {
                                    progress = false;
                                    mmlWrite(":");
                                }
                                mmlWrite(put);
                            }
                        }
                        break;
                    case 0xc:   // program change
                        {
                            if ((t.midiChannel.channelNumber == 0x9) && useDrumMap)
                            {
                                continue;
                            }
                            if (progress)
                            {
                                progress = false;
                                mmlWrite(":");
                            }
                            mmlWrite(string.Format("@(prg{0})", (ev.arg0 + 1).ToString("D3")));
                            t.programNo = ev.arg0;
                        }
                        break;
                    case 0xe:   // pitch bend
                        {
                            if (progress)
                            {
                                progress = false;
                                mmlWrite(":");
                            }
                            mmlWrite(string.Format("@p{0}", (int)(((uint)ev.arg1 << 7) + ev.arg0) - 0x2000));
                        }
                        break;
                    default:
                        {
                            //xxxxx
                        }
                        break;
                }
            }
            return false;
        }
        private void processTracks()
        {
            uint measureNumber = 1;
            uint measureLen = 32 * 4;
            uint measureStep = 0;
            uint step = 0;
            int sysindex = 0;
            bool active;
            do
            {
                Debug.Assert(measureLen >= measureStep);
                uint dstep = measureLen - measureStep;
                while (sysindex < systemEvent.Count)
                {
                    var ev = systemEvent[sysindex];
                    Debug.Assert(ev.step >= step);
                    if (ev.step != step)
                    {
                        dstep = ev.step - step;
                        if (dstep > measureLen - measureStep)
                        {
                            dstep = measureLen - measureStep;
                        }
                        break;
                    }
                    sysindex++;
                    if (ev.state != 0xffU)
                    {
                        continue;
                    }
                    switch (ev.arg0)
                    {
                        case 0x51:
                            {
                                uint tempo = ((uint)ev.opt[0] << 16) | ((uint)ev.opt[1] << 8) | ((uint)ev.opt[2] << 0);
                                mmlWriteLine("!tempo " + 60000000 / tempo);
                            }
                            break;
                        case 0x58:
                            {
                                uint num = ev.opt[0];
                                uint den = 1U << ev.opt[1];
                                measureLen = num * (128U >> ev.opt[1]);
                                measureStep = 0;
                                dstep = measureLen;
                                mmlWriteLine("!measure " + num + "/" + den);
                            }
                            break;
                    }
                }
                if(measureStep == 0)
                {
                    foreach (var t in mmlTrack)
                    {
                        if ((t.index != t.midiChannel.midiEvent.Count) || (t.notes.Count != 0))
                        {
                            mmlWriteLine("; #" + measureNumber++);
                            break;
                        }
                    }
                }
                active = false;
                foreach (var t in mmlTrack)
                {
#if false
                        if(t.midiChannel.channelNumber != 2)
                        {
                            continue;
                        }
#endif
                    uint st = step;
                    uint ed = step + dstep;
                    if ((t.index == t.midiChannel.midiEvent.Count) && (t.notes.Count == 0))
                    {
                        continue;
                    }
                    active = true;
                    mmlWrite(string.Format("t{0}=", t.midiChannel.assignedTrackNumber.ToString("d2")));
                    do
                    {
                        bool progress = false;
                        uint stn = ed;
                        int stindex = t.index;
                        for (int tindex = t.index; tindex < t.midiChannel.midiEvent.Count; tindex++)
                        {
                            var ev = t.midiChannel.midiEvent[tindex];
                            if (ev.step != st)
                            {
                                stn = ev.step;
                                if (stn > ed)
                                {
                                    stn = ed;
                                }
                                break;
                            }
                            if ((ev.state == 0x9) || (ev.state == 0xa) || (ev.state == 0xd))
                            {
                                for (var nn = t.notes.First; nn != null; nn = nn.Next)
                                {
                                    if (nn.Value.number != ev.arg0)
                                    {
                                        continue;
                                    }
                                    if (nn.Value.state == 0x9)
                                    {
                                        continue;
                                    }
                                    Debug.Assert(nn.Value.goff == st);
                                    Debug.Assert(nn.Value.gend == st);
                                    // after pressure
                                    var n = new MmlTrackInfo.NoteInfo();
                                    n.state = ev.state;
                                    n.number = ev.arg0;
                                    n.velocity = ev.arg1;
                                    n.goff = st + ev.length;
                                    n.gend = st;
                                    nn.Value = n;
                                    ev.state = 0;
                                    break;
                                }
                            }
                        }
                        for (var nn = t.notes.Last; nn != null;)
                        {
                            if ((nn.Value.goff > st) || (nn.Value.gend > st))
                            {
                                break;
                            }
                            Debug.Assert(nn.Value.gend == st);
                            var nt = nn.Previous;
                            t.notes.Remove(nn);
                            nn = nt;
                        }
                        for (var nn = t.notes.First; nn != null; nn = nn.Next)
                        {
                            if (nn.Value.gend > st)
                            {
                                continue;
                            }
                            Debug.Assert(nn.Value.gend == st);
                            if (nn.Value.gend < nn.Value.goff)
                            {
                                if (progress)
                                {
                                    mmlWrite(":");
                                }
                                if (nn.Value.state == 0x8)
                                {
                                    mmlWriteRest(t, nn.Value, st, ed);
                                }
                                else
                                {
                                    mmlWriteNote(t, nn.Value, st, ed, nn.Value.state != 0x9);
                                    if ((nn.Value.gend < nn.Value.goff) || (nn.Value.state != 0x9))
                                    {
                                        mmlWrite("^");
                                    }
                                    else if ((nn.Value.flags & 1U) != 0)
                                    {
                                        mmlWrite("&&");
                                    }
                                }
                                progress = true;
                            }
                            else
                            {
                                if (!putMidiEvents(t, nn, st, ed, ref progress))
                                {
                                    var n = new MmlTrackInfo.NoteInfo();
                                    n.state = 0x8;
                                    n.number = 0;
                                    n.velocity = 0;
                                    n.goff = stn;
                                    n.gend = st;
                                    nn.Value = n;
                                    if (progress)
                                    {
                                        mmlWrite(":");
                                    }
                                    mmlWriteRest(t, n, st, ed);
                                    progress = true;
                                }
                            }
                        }
                        while (putMidiEvents(t, null, st, ed, ref progress))
                        {
                        }
                        uint stx = ed;
                        for (var nn = t.notes.First; nn != null; nn = nn.Next)
                        {
                            if ((nn.Value.gend > st) && (nn.Value.gend < stx))
                            {
                                stx = nn.Value.gend;
                            }
                        }
                        if ((stn < stx) || !progress)
                        {
                            var n = new MmlTrackInfo.NoteInfo();
                            n.state = 0x8;
                            n.number = 0;
                            n.velocity = 0;
                            n.goff = stn;
                            n.gend = st;
                            t.notes.AddLast(n);
                            if (progress)
                            {
                                mmlWrite(":");
                            }
                            mmlWriteRest(t, n, st, ed);
                            progress = true;
                            Debug.Assert(n.gend <= stn);
                            if (stx > n.gend)
                            {
                                stx = n.gend;
                            }
                        }
                        Debug.Assert(t.notes.Count <= 8);
                        Debug.Assert(st != stx);
                        st = stx;
                    }
                    while (st != ed);

                    for (var nn = t.notes.Last; nn != null;)
                    {
                        Debug.Assert(nn.Value.gend <= ed);
                        if ((nn.Value.goff > st) || (nn.Value.gend > st))
                        {
                            break;
                        }
                        Debug.Assert(nn.Value.gend == st);
                        var nt = nn.Previous;
                        t.notes.Remove(nn);
                        nn = nt;
                    }
                    mmlWriteLine("");
                }
                mmlWriteLine("");
                step += dstep;
                measureStep += dstep;
                Debug.Assert(measureStep <= measureLen);
                if (measureStep == measureLen)
                {
                    measureStep = 0;
                }
            } while (active);
        }
        public void Do(string Title, ToneDataSet ToneDataSet, uint Port)
        {
            setupHeader(Title, ToneDataSet, Port);

            prepareTracks();

            processTracks();
        }
    }
}
